import tkinter as tk
from tkinter import messagebox

class BMICalculator:
    def __init__(self, root):
        self.root = root
        self.root.title("Calculadora de IMC")

        # Adicionando rótulos, entradas e botões
        tk.Label(root, text="Altura (cm):").grid(row=0, column=0, padx=10, pady=10)
        self.altura_entry = tk.Entry(root)
        self.altura_entry.grid(row=0, column=1, padx=10, pady=10)

        tk.Label(root, text="Peso (kg):").grid(row=1, column=0, padx=10, pady=10)
        self.peso_entry = tk.Entry(root)
        self.peso_entry.grid(row=1, column=1, padx=10, pady=10)

        self.calcular_button = tk.Button(root, text="Calcular IMC", command=self.calculate_bmi)
        self.calcular_button.grid(row=2, column=0, columnspan=2, padx=10, pady=10)

        self.resultado_label = tk.Label(root, text="Seu IMC: ")
        self.resultado_label.grid(row=3, column=0, columnspan=2, padx=10, pady=10)

    def calculate_bmi(self):
        try:
            altura = float(self.altura_entry.get()) / 100  # convertendo para metros
            peso = float(self.peso_entry.get())
            bmi = peso / (altura ** 2)
            self.show_bmi_category(bmi)
        except ValueError:
            messagebox.showerror("Erro", "Por favor, insira valores válidos para altura e peso.")

    def show_bmi_category(self, bmi):
        if bmi < 18.5:
            categoria = "Abaixo do peso"
        elif 18.5 <= bmi < 24.9:
            categoria = "Peso normal"
        elif 25 <= bmi < 29.9:
            categoria = "Sobrepeso"
        else:
            categoria = "Obesidade"

        self.resultado_label.config(text=f"Seu IMC: {bmi:.2f} - {categoria}")

if __name__ == "__main__":
    root = tk.Tk()
    app = BMICalculator(root)
    root.mainloop()