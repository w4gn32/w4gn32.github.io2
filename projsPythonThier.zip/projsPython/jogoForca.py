import random

def escolha_palavra():
    palavras = ["python", "java", "javascript", "ruby", "php", "html", "css", "cplusplus"]
    return random.choice(palavras)

def display_palavra(palavra, letras_adivinhadas):
    displayed_palavra = ""
    for letra in palavra:
        if letra in letras_adivinhadas:
            displayed_palavra += letra
        else:
            displayed_palavra += "_"
    return displayed_palavra

def palavra_descoberta(palavra, letras_adivinhadas):
    for letra in palavra:
        if letra not in letras_adivinhadas:
            return False
    return True

def main():
    print("Bem-vindo ao Jogo da Forca!")
    palavra_para_adivinhar = escolha_palavra()
    letras_adivinhadas = []
    tentativas = 6

    while tentativas > 0:
        print("\nPalavra:", display_palavra(palavra_para_adivinhar, letras_adivinhadas))
        print("Tentativas restantes:", tentativas)
        adivinhar = input("Digite uma letra: ").lower()

        if len(adivinhar) != 1 or not adivinhar.isalpha():
            print("Por favor, digite apenas uma letra válida.")
            continue

        if adivinhar in letras_adivinhadas:
            print("Você já tentou essa letra. Tente outra.")
            continue

        letras_adivinhadas.append(adivinhar)

        if adivinhar in palavra_para_adivinhar:
            print("Letra correta!")
            if palavra_descoberta(palavra_para_adivinhar, letras_adivinhadas):
                print("\nParabéns! Você adivinhou a palavra:", palavra_para_adivinhar)
                break
        else:
            print("Letra incorreta!")
            tentativas -= 1

    if tentativas == 0:
        print("\nFim de jogo! A palavra era:", palavra_para_adivinhar)

if __name__ == "__main__":
    main()
